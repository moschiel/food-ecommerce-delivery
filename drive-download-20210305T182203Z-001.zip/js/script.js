let form = document.getElementById("register-container");
let submit = document.getElementById("btn-submit");

submit.addEventListener('click', function(e){
    e.preventDefault();

    console.log('funcionou');
});
